from main import app
from flask import render_template

@app.route('/')
@app.route('/index')
def home():
    return render_template('index.html')

@app.route('/menu')
def menu():
    return render_template('menu.html')

